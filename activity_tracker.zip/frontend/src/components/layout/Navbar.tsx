import React, { useState, useEffect, useRef } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  Sparkles,
  Search,
  Bell,
  Plus,
  User,
  LogOut,
  Sliders,
  CheckCircle2,
  Layers,
  ChevronDown
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { getInitials } from '../../utils/stringUtils';
import { useNotificationStore } from '../../store/notificationStore';
import { useActivityStore } from '../../store/activityStore';
import { apiClient } from '../../services/apiClient';

export const Navbar: React.FC = () => {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  const { notifications, markAsRead, markAllAsRead } = useNotificationStore();

  useEffect(() => {
    const q = searchQuery.trim();
    if (!q) {
      setSearchResults([]);
      setIsSearching(false);
      setSearchError(null);
      return;
    }

    setIsSearching(true);
    setSearchError(null);

    const debounceId = setTimeout(async () => {
      try {
        const response: any = await apiClient.activities.getAll({ q, limit: 15 });
        const results = response.data?.activities || response.activities || [];
        setSearchResults(results);
      } catch (err: any) {
        setSearchError('Search failed. Please try again.');
        console.error('Search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 400);

    return () => clearTimeout(debounceId);
  }, [searchQuery]);

  const navRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
        setShowNotifications(false);
        setShowSearch(false);
      }
    };
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowUserMenu(false);
        setShowNotifications(false);
        setShowSearch(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Records', path: '/records' },
    { name: 'Reports', path: '/reports' },
    { name: 'Insights', path: '/insights' },
  ];

  return (
    <header style={{
      position: 'sticky',
      top: 0,
      zIndex: 40,
      backgroundColor: 'rgba(245, 237, 224, 0.90)',
      backdropFilter: 'blur(16px)',
      borderBottom: '1px solid rgba(139, 90, 43, 0.12)',
      padding: '0.85rem 2rem',
    }}>
      <div style={{
        maxWidth: '1280px',
        margin: '0 auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        {/* Left: Brand Logo & Navigation */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '2.75rem' }}>
          <NavLink to="/" style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', textDecoration: 'none' }}>
            {/* Logo Icon */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '2.5px',
              padding: '4px',
              borderRadius: '6px',
              background: 'rgba(124, 77, 46, 0.15)',
              border: '1px solid rgba(124, 77, 46, 0.35)',
            }}>
              <div style={{ width: '6px', height: '6px', backgroundColor: '#C8874A', borderRadius: '1.5px' }} />
              <div style={{ width: '6px', height: '6px', backgroundColor: '#7C4D2E', borderRadius: '1.5px' }} />
              <div style={{ width: '6px', height: '6px', backgroundColor: '#7C4D2E', borderRadius: '1.5px' }} />
              <div style={{ width: '6px', height: '6px', backgroundColor: '#C8874A', borderRadius: '1.5px' }} />
            </div>
            <span style={{
              fontSize: '1.25rem',
              fontWeight: 800,
              letterSpacing: '-0.02em',
              color: '#2C1810',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
            }}>
              WorkLog <span style={{ color: '#7C4D2E' }}>AI</span>
            </span>
          </NavLink>

          {/* Navigation Links */}
          <nav style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
            {navLinks.map((link) => (
              <NavLink
                key={link.name}
                to={link.path}
                style={({ isActive }) => ({
                  color: isActive ? '#2C1810' : '#7A6355',
                  fontSize: '0.9rem',
                  fontWeight: isActive ? 600 : 500,
                  textDecoration: 'none',
                  position: 'relative',
                  padding: '0.4rem 0',
                  transition: 'color 0.2s ease',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                })}
              >
                {({ isActive }) => (
                  <>
                    <span>{link.name}</span>
                    {isActive && (
                      <div style={{
                        position: 'absolute',
                        bottom: '-4px',
                        width: '4px',
                        height: '4px',
                        borderRadius: '50%',
                        backgroundColor: '#7C4D2E',
                        boxShadow: '0 0 8px rgba(124, 77, 46, 0.6)',
                      }} />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>
        </div>

        {/* Right: Actions & User */}
        <div ref={navRef} style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
          {/* Search Trigger */}
          <button
            onClick={() => setShowSearch(!showSearch)}
            aria-label="Search"
            style={{
              background: 'rgba(124, 77, 46, 0.06)',
              border: '1px solid rgba(139, 90, 43, 0.15)',
              color: '#7A6355',
              borderRadius: '9999px',
              padding: '0.45rem 0.85rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              fontSize: '0.8rem',
              cursor: 'pointer',
              transition: 'all 0.2s',
            }}
          >
            <Search size={14} />
            <span style={{ color: '#A89080' }}>Search records...</span>
          </button>

          {/* Search Dropdown */}
          {showSearch && (
            <div style={{
              position: 'absolute',
              top: 'calc(100% + 8px)',
              right: '250px',
              width: '400px',
              backgroundColor: '#FEFCF8',
              border: '1px solid rgba(139, 90, 43, 0.15)',
              borderRadius: '14px',
              padding: '1rem',
              boxShadow: '0 12px 30px rgba(124, 77, 46, 0.12)',
              zIndex: 50,
            }}>
              <input
                autoFocus
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{ width: '100%', padding: '0.5rem', borderRadius: '8px', border: '1px solid #ccc', marginBottom: '1rem' }}
              />
              <div style={{ maxHeight: '400px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                {!searchQuery.trim() && (
                  <div style={{ fontSize: '0.85rem', color: '#A89080', padding: '1rem', textAlign: 'center' }}>
                    Type to search across all records...
                  </div>
                )}
                {isSearching && (
                  <div style={{ fontSize: '0.85rem', color: '#7A6355', padding: '1rem', textAlign: 'center' }}>
                    Searching...
                  </div>
                )}
                {searchError && (
                  <div style={{ fontSize: '0.85rem', color: '#D32F2F', padding: '1rem', textAlign: 'center' }}>
                    {searchError}
                  </div>
                )}
                {!isSearching && !searchError && searchQuery.trim() && searchResults.length === 0 && (
                  <div style={{ fontSize: '0.85rem', color: '#7A6355', padding: '1rem', textAlign: 'center' }}>
                    No results found for "{searchQuery}"
                  </div>
                )}
                {!isSearching && searchResults.map(res => (
                  <div key={res.id || res._id} onClick={() => { setShowSearch(false); navigate(`/records/${res.id || res._id}`); }} className="glass-card-interactive" style={{ cursor: 'pointer', padding: '0.85rem', borderRadius: '8px', border: '1px solid rgba(139, 90, 43, 0.1)', background: 'rgba(254, 252, 248, 0.9)' }}>
                    <div style={{ fontWeight: 600, fontSize: '0.9rem', color: '#2C1810' }}>{res.title || res.project || 'Work Entry'}</div>
                    <div style={{ fontSize: '0.75rem', color: '#7A6355', margin: '0.3rem 0' }}>
                      <span className="tag-chip" style={{ fontSize: '0.65rem', padding: '0.15rem 0.4rem', marginRight: '0.4rem' }}>{res.category}</span>
                      {res.workType && <span style={{ marginRight: '0.4rem' }}>{res.workType}</span>}
                      {res.workDate && `• ${new Date(res.workDate).toLocaleDateString()}`}
                    </div>
                    <div style={{ fontSize: '0.8rem', color: '#4A2E1A', marginTop: '0.4rem', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', lineHeight: '1.4' }}>
                      {res.aiRefinedText || res.text}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notification Bell */}
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              style={{
                background: 'transparent',
                border: 'none',
                color: '#7A6355',
                cursor: 'pointer',
                padding: '0.4rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: '50%',
                position: 'relative',
              }}
            >
              <Bell size={18} />
              <span style={{
                position: 'absolute',
                top: '4px',
                right: '4px',
                width: '7px',
                height: '7px',
                borderRadius: '50%',
                backgroundColor: '#C8874A',
              }} />
            </button>

            {/* Notification Dropdown */}
            {showNotifications && (
              <div style={{
                position: 'absolute',
                top: 'calc(100% + 8px)',
                right: 0,
                width: '280px',
                backgroundColor: '#FEFCF8',
                border: '1px solid rgba(139, 90, 43, 0.15)',
                borderRadius: '14px',
                padding: '1rem',
                boxShadow: '0 12px 30px rgba(124, 77, 46, 0.12)',
                zIndex: 50,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                  <span style={{ fontSize: '0.85rem', fontWeight: 600, color: '#2C1810' }}>Notifications</span>
                  <span onClick={markAllAsRead} style={{ fontSize: '0.75rem', color: '#7C4D2E', cursor: 'pointer' }}>Mark all read</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                  {notifications.length === 0 && <div style={{ fontSize: '0.8rem', color: '#7A6355' }}>No notifications</div>}
                  {notifications.map(n => (
                    <div
                      key={n.id}
                      onClick={() => {
                        markAsRead(n.id);
                        setShowNotifications(false);
                        if (n.targetRoute) navigate(n.targetRoute);
                      }}
                      style={{ fontSize: '0.8rem', color: n.read ? '#7A6355' : '#4A2E1A', padding: '0.4rem 0', borderBottom: '1px solid rgba(139, 90, 43, 0.08)', cursor: n.targetRoute ? 'pointer' : 'default', fontWeight: n.read ? 'normal' : 'bold' }}
                    >
                      {n.title}: {n.message}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Primary CTA: Add Today's Work */}
          {/* <button
            onClick={() => navigate('/add-work')}
            className="btn-primary"
            style={{
              padding: '0.5rem 1.15rem',
              fontSize: '0.85rem',
              fontWeight: 600,
            }}
          >
            <Plus size={16} strokeWidth={2.5} />
            <span>Add Today's Work</span>
          </button> */}

          {/* User Profile Avatar KD */}
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              style={{
                width: '38px',
                height: '38px',
                borderRadius: '50%',
                backgroundColor: '#FEFCF8',
                border: '2px solid rgba(139, 90, 43, 0.15)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#7C4D2E',
                fontWeight: 700,
                fontSize: '0.875rem',
                cursor: 'pointer',
                boxShadow: '0 2px 8px rgba(124, 77, 46, 0.2)',
              }}
            >
              {user?.initials || getInitials(user?.name)}
            </button>

            {/* Profile Dropdown */}
            {showUserMenu && (
              <div style={{
                position: 'absolute',
                top: 'calc(100% + 8px)',
                right: 0,
                width: '230px',
                backgroundColor: '#FEFCF8',
                border: '1px solid rgba(139, 90, 43, 0.15)',
                borderRadius: '14px',
                padding: '0.75rem',
                boxShadow: '0 12px 30px rgba(124, 77, 46, 0.12)',
                zIndex: 50,
              }}>
                <div style={{ padding: '0.5rem 0.6rem', borderBottom: '1px solid rgba(139, 90, 43, 0.1)', marginBottom: '0.4rem' }}>
                  <div style={{ fontWeight: 600, fontSize: '0.9rem', color: '#2C1810' }}>{user?.name || ''}</div>
                  <div style={{ fontSize: '0.75rem', color: '#7A6355' }}>{user?.jobRole || ''}</div>
                </div>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    navigate('/profile');
                  }}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.6rem',
                    padding: '0.5rem 0.6rem',
                    backgroundColor: 'transparent',
                    border: 'none',
                    color: '#4A2E1A',
                    fontSize: '0.825rem',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    textAlign: 'left',
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'rgba(124, 77, 46, 0.07)')}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                >
                  <Sliders size={14} color="#7A6355" />
                  <span>Work Profile Setup</span>
                </button>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    logout();
                    navigate('/login');
                  }}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.6rem',
                    padding: '0.5rem 0.6rem',
                    backgroundColor: 'transparent',
                    border: 'none',
                    color: '#F87171',
                    fontSize: '0.825rem',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    textAlign: 'left',
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'rgba(239, 68, 68, 0.1)')}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                >
                  <LogOut size={14} />
                  <span>Log Out</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
