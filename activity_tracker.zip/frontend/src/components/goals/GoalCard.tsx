﻿import React from 'react';
import { Target, Trophy, Calendar, CheckCircle2, Link2, Sparkles } from 'lucide-react';
import { AchievedGoal } from '../../types/goal';

interface GoalCardProps {
  goal: AchievedGoal;
  onDelete?: (id: string) => void;
}

export const GoalCard: React.FC<GoalCardProps> = ({ goal, onDelete }) => {
  return (
    <div className="glass-card-interactive" style={{
      padding: '1.5rem 1.75rem',
      borderRadius: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
      position: 'relative',
    }}>
      {/* Top Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <div style={{
            width: '32px',
            height: '32px',
            borderRadius: '10px',
            backgroundColor: 'rgba(176, 120, 72, 0.12)',
            border: '1px solid rgba(176, 120, 72, 0.25)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#B07848',
          }}>
            <Trophy size={16} />
          </div>
          <div>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#2C1810', margin: 0 }}>
              {goal.title}
            </h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginTop: '0.2rem' }}>
              <span style={{ fontSize: '0.75rem', color: '#7A6355' }}>{goal.quarter || 'Q3 2026'}</span>
              <span style={{ color: '#A89080' }}>·</span>
              <span className="tag-chip tag-chip-project" style={{ fontSize: '0.7rem', padding: '0.15rem 0.55rem' }}>
                {goal.project || 'Payment System'}
              </span>
            </div>
          </div>
        </div>

        {/* Impact score badge */}
        {goal.impactScore && (
          <div style={{
            backgroundColor: 'rgba(124, 77, 46, 0.1)',
            border: '1px solid rgba(124, 77, 46, 0.25)',
            color: '#8B5A2B',
            borderRadius: '9999px',
            padding: '0.25rem 0.75rem',
            fontSize: '0.75rem',
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            gap: '0.3rem',
          }}>
            <Sparkles size={12} color="#C8874A" />
            <span>Impact {goal.impactScore}%</span>
          </div>
        )}
      </div>

      {/* Description */}
      <p style={{ fontSize: '0.9rem', color: '#4A2E1A', lineHeight: '1.6', margin: 0 }}>
        {goal.description}
      </p>

      {/* Key Outcomes */}
      {goal.keyOutcomes && goal.keyOutcomes.length > 0 && (
        <div style={{
          backgroundColor: 'rgba(139, 90, 43, 0.05)',
          border: '1px solid rgba(255, 255, 255, 0.05)',
          borderRadius: '12px',
          padding: '0.85rem 1rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.4rem',
        }}>
          <div style={{ fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.05em', color: '#A89080' }}>
            KEY DELIVERABLES & OUTCOMES
          </div>
          {goal.keyOutcomes.map((outcome, idx) => (
            <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.825rem', color: '#7A6355' }}>
              <CheckCircle2 size={13} color="#7C4D2E" />
              <span>{outcome}</span>
            </div>
          ))}
        </div>
      )}

      {/* Linked Activities */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingTop: '0.5rem',
        borderTop: '1px solid rgba(139, 90, 43, 0.1)',
        fontSize: '0.75rem',
        color: '#A89080',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <Link2 size={13} color="#94A3B8" />
          <span>{goal.relatedActivityIds.length} Linked Activity Logs</span>
        </div>
        <div>
          Completed on {goal.completedAt}
        </div>
      </div>
    </div>
  );
};
