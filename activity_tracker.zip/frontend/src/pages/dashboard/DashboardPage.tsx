import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FileText, 
  Trophy, 
  Target, 
  Briefcase, 
  Sparkles, 
  ArrowRight, 
  Plus, 
  ChevronRight,
  Calendar
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useActivityStore } from '../../store/activityStore';
import { useGoalStore } from '../../store/goalStore';
import { getInitials } from '../../utils/stringUtils';

export const DashboardPage: React.FC = () => {
  const { user } = useAuthStore();
  const { activities } = useActivityStore();
  const { goals } = useGoalStore();
  const navigate = useNavigate();

  const firstName = user?.name ? user.name.split(' ')[0] : 'Guest';
  const initials = user?.initials || getInitials(user?.name);

  const totalEntries = activities.length;
  const totalAchievements = activities.filter((a) => a.isAchievement).length;
  const totalGoals = goals.length;
  const activeProjects = new Set(activities.map((a) => a.project)).size;

  const reviewYear = user?.reviewYear || new Date().getFullYear();

  // Activity Heatmap generator data (12 months x 4 weeks x 7 days)
  const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

  const getCellIntensity = (mIndex: number, dayIndex: number) => {
    const targetDate = new Date(reviewYear, mIndex, dayIndex + 1);
    
    // Ignore future dates
    if (targetDate > new Date()) return 0;
    
    const count = activities.filter((a) => {
      if (!a.workDate) return false;
      const d = new Date(a.workDate);
      return d.getFullYear() === reviewYear && d.getMonth() === mIndex && d.getDate() === dayIndex + 1;
    }).length;

    if (count === 0) return 0;
    if (count === 1) return 1;
    if (count <= 3) return 2;
    return 3;
  };

  const getHeatmapColor = (intensity: number) => {
    switch (intensity) {
      case 3: return '#7C4D2E'; // High — rich brown
      case 2: return '#B07848'; // Medium — warm caramel
      case 1: return '#D4B896'; // Low — soft tan
      default: return 'rgba(139, 90, 43, 0.08)'; // None — barely-there
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      {/* Header Greeting matching Wireframe 4 */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        gap: '1rem',
      }}>
        <div>
          <h1 style={{
            fontSize: '2.25rem',
            fontWeight: 800,
            color: '#2C1810',
            letterSpacing: '-0.03em',
            display: 'flex',
            alignItems: 'center',
            gap: '0.6rem',
          }}>
            Good morning, {initials} 👋
          </h1>
          <p style={{
            fontSize: '0.95rem',
            color: '#7A6355',
            marginTop: '0.35rem',
          }}>
            Here's a look at your work so far in {user?.reviewYear || 2026}.
          </p>
        </div>

        <button
          onClick={() => navigate('/add-work')}
          className="btn-primary"
          style={{
            padding: '0.65rem 1.35rem',
            fontSize: '0.9rem',
            fontWeight: 600,
          }}
        >
          <Plus size={18} strokeWidth={2.5} />
          <span>Add Today's Work</span>
        </button>
      </div>

      {/* 4 Stat Metric Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: '1.25rem',
      }}>
        {/* Card 1: ENTRIES */}
        <div 
          className="glass-card-interactive" 
          style={{ padding: '1.5rem 1.6rem', cursor: 'pointer' }}
          onClick={() => navigate('/records')}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#7A6355', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.06em' }}>
            <FileText size={15} color="#A89080" />
            <span>ENTRIES</span>
          </div>
          <div style={{ fontSize: '2.1rem', fontWeight: 800, color: '#2C1810', margin: '0.6rem 0 0.2rem 0' }}>
            {totalEntries}
          </div>
          <div style={{ fontSize: '0.8rem', color: '#A89080' }}>
            Total Work Entries
          </div>
        </div>

        {/* Card 2: ACHIEVEMENTS */}
        <div 
          className="glass-card-interactive" 
          style={{ padding: '1.5rem 1.6rem', cursor: 'pointer' }}
          onClick={() => navigate('/achieved-goals')}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#7A6355', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.06em' }}>
            <Trophy size={15} color="#C8874A" />
            <span>ACHIEVEMENTS</span>
          </div>
          <div style={{ fontSize: '2.1rem', fontWeight: 800, color: '#2C1810', margin: '0.6rem 0 0.2rem 0' }}>
            {totalAchievements}
          </div>
          <div style={{ fontSize: '0.8rem', color: '#A89080' }}>
            Milestones reached
          </div>
        </div>

        {/* Card 3: ACHIEVED GOALS */}
        <div 
          onClick={() => navigate('/achieved-goals')}
          className="glass-card-interactive" 
          style={{ padding: '1.5rem 1.6rem', cursor: 'pointer' }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#7A6355', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.06em' }}>
            <Target size={15} color="#B07848" />
            <span>ACHIEVED GOALS</span>
          </div>
          <div style={{ fontSize: '2.1rem', fontWeight: 800, color: '#2C1810', margin: '0.6rem 0 0.2rem 0' }}>
            {totalGoals}
          </div>
          <div style={{ fontSize: '0.8rem', color: '#A89080' }}>
            Goals Achieved
          </div>
        </div>

        {/* Card 4: PROJECTS */}
        <div className="glass-card-interactive" style={{ padding: '1.5rem 1.6rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#7A6355', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.06em' }}>
            <Briefcase size={15} color="#8B5A2B" />
            <span>PROJECTS</span>
          </div>
          <div style={{ fontSize: '2.1rem', fontWeight: 800, color: '#2C1810', margin: '0.6rem 0 0.2rem 0' }}>
            {activeProjects}
          </div>
          <div style={{ fontSize: '0.8rem', color: '#A89080' }}>
            Active Projects
          </div>
        </div>
      </div>

      {/* Two Column Layout: Recent Work & AI Insight */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(0, 1.4fr) minmax(0, 1fr)',
        gap: '1.5rem',
        alignItems: 'start',
      }}>
        {/* Left Column: Recent Work Timeline Card */}
        <div className="glass-panel" style={{ padding: '1.75rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#2C1810' }}>Recent Work</h2>
          </div>

          {/* Timeline Nodes */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', position: 'relative' }}>
            {activities.length === 0 ? (
              <div style={{ padding: '2rem', textAlign: 'center', color: '#A89080', fontSize: '0.9rem' }}>
                No recent work found. Start logging!
              </div>
            ) : (
              activities.slice(0, 3).map((act) => (
                <div 
                  key={act.id}
                  onClick={() => navigate(`/records/${act.id}`)}
                  className="glass-card-interactive"
                  style={{
                    padding: '1.15rem 1.25rem',
                    position: 'relative',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.4rem' }}>
                    <span style={{ fontSize: '0.75rem', fontWeight: 600, color: '#7A6355' }}>
                      {act.displayDate}
                    </span>
                    {act.aiConfidence && act.aiConfidence > 0.8 && (
                      <span style={{
                        fontSize: '0.7rem',
                        color: '#7C4D2E',
                        backgroundColor: 'rgba(124, 77, 46, 0.1)',
                        border: '1px solid rgba(124, 77, 46, 0.25)',
                        padding: '0.15rem 0.55rem',
                        borderRadius: '9999px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.25rem',
                      }}>
                        <Sparkles size={11} /> AI Logged
                      </span>
                    )}
                  </div>
                  <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#2C1810', marginBottom: '0.6rem' }}>
                    {act.title}
                  </h3>
                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <span className="tag-chip tag-chip-category" style={{ fontSize: '0.75rem', padding: '0.2rem 0.6rem' }}>
                      {act.category}
                    </span>
                    <span className="tag-chip tag-chip-project" style={{ fontSize: '0.75rem', padding: '0.2rem 0.6rem' }}>
                      {act.project}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          <div style={{ marginTop: '1.25rem', paddingTop: '0.75rem' }}>
            <button
              onClick={() => navigate('/records')}
              style={{
                background: 'transparent',
                border: 'none',
                color: '#7C4D2E',
                fontSize: '0.85rem',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
              }}
            >
              <span>View full history</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>

        {/* Right Column: AI Insight Glowing Card (Matches Wireframe 4) */}
        <div className="ai-glow-card" style={{ padding: '2rem 1.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#8B5A2B', marginBottom: '1.25rem' }}>
            <Sparkles size={18} color="#C8874A" />
            <h2 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#2C1810' }}>AI Insight</h2>
          </div>

          <blockquote style={{
            fontSize: '0.925rem',
            lineHeight: '1.6',
            color: '#4A2E1A',
            fontStyle: 'normal',
            marginBottom: '2rem',
          }}>
            {activities.length > 0 ? (
              <>
                "Your recent work has primarily focused on <strong style={{ color: '#7C4D2E' }}>{activities[0]?.project || 'projects'}</strong>. Keep up the momentum!"
              </>
            ) : (
              "Log some work entries to generate AI insights into your patterns and achievements."
            )}
          </blockquote>

          <button
            onClick={() => navigate('/insights')}
            className="btn-secondary"
            style={{
              width: '100%',
              padding: '0.75rem',
              borderRadius: '9999px',
              backgroundColor: 'rgba(124, 77, 46, 0.08)',
              border: '1px solid rgba(124, 77, 46, 0.25)',
              color: '#2C1810',
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem',
            }}
          >
            <span>Explore Insights</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </div>

      {/* Bottom Section: 2026 Activity Heatmap */}
      <div className="glass-panel" style={{ padding: '1.75rem' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#2C1810', marginBottom: '1.25rem' }}>
          {reviewYear} Activity
        </h2>

        {/* Activity Heatmap Grid */}
        <div style={{ overflowX: 'auto', paddingBottom: '0.5rem' }}>
          <div style={{ minWidth: '700px' }}>
            {/* Heatmap cells */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(12, 1fr)',
              gap: '1rem',
            }}>
              {months.map((month, mIndex) => (
                <div key={month} style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                  {/* 4 weeks / columns of days in this month */}
                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(4, 1fr)',
                    gridTemplateRows: 'repeat(7, 10px)',
                    gap: '3px',
                  }}>
                    {Array.from({ length: 28 }).map((_, dIndex) => {
                      const intensity = getCellIntensity(mIndex, dIndex);
                      return (
                        <div
                          key={dIndex}
                          title={`${month} ${reviewYear} - Activity Level: ${intensity}`}
                          style={{
                            width: '10px',
                            height: '10px',
                            borderRadius: '2px',
                            backgroundColor: getHeatmapColor(intensity),
                            transition: 'all 0.15s ease',
                          }}
                        />
                      );
                    })}
                  </div>
                  {/* Month Label */}
                  <span style={{
                    fontSize: '0.7rem',
                    fontWeight: 700,
                    color: '#A89080',
                    textAlign: 'center',
                    marginTop: '0.5rem',
                    letterSpacing: '0.05em',
                  }}>
                    {month}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
