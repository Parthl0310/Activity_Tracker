import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Edit3, 
  Trash2, 
  Calendar, 
  Folder, 
  Sparkles, 
  Tag, 
  CheckCircle2, 
  Layers,
  Paperclip
} from 'lucide-react';
import { useActivityStore } from '../../store/activityStore';

export const WorkDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getActivityById, deleteActivity, updateActivity } = useActivityStore();

  const activity = getActivityById(id || 'act_002') || {
    id: 'act_002',
    userId: 'usr_kd_001',
    title: 'Fixed checkout payment bug',
    text: 'Fixed the checkout flow failure caused by incorrect payment-state handling. The root cause was an asynchronous race condition during token verification that resulted in dropped state updates when the payment gateway responded faster than the local state machine could process. Implemented an optimistic locking mechanism and added comprehensive unit tests for the specific failure mode.',
    aiRefinedText: 'Fixed the checkout flow failure caused by incorrect payment-state handling. The root cause was an asynchronous race condition during token verification that resulted in dropped state updates when the payment gateway responded faster than the local state machine could process. Implemented an optimistic locking mechanism and added comprehensive unit tests for the specific failure mode.',
    workDate: '2026-08-18',
    displayDate: '18 Aug 2026',
    project: 'Payment System',
    category: 'Bug Fix',
    workType: 'Technical',
    skills: ['Backend', 'Debugging'],
    keywords: ['Payment', 'Checkout', 'API', 'Bug'],
    enrichmentStatus: 'completed',
    aiClassificationSummary: 'High confidence classification based on keyword extraction (checkout, payment-state, race condition).',
    createdAt: '2026-08-18T14:15:00Z',
  };

  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(activity.title);
  const [editedText, setEditedText] = useState(activity.text);

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this record?')) {
      await deleteActivity(activity.id);
      navigate('/records');
    }
  };

  const handleSaveEdit = async () => {
    await updateActivity(activity.id, {
      title: editedTitle,
      text: editedText,
    });
    setIsEditing(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
      {/* Top Breadcrumb link */}
      <div>
        <Link
          to="/records"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.4rem',
            color: '#7A6355',
            fontSize: '0.85rem',
            textDecoration: 'none',
            transition: 'color 0.15s ease',
          }}
          onMouseEnter={(e) => (e.currentTarget.style.color = '#4A2E1A')}
          onMouseLeave={(e) => (e.currentTarget.style.color = '#94A3B8')}
        >
          <ArrowLeft size={15} />
          <span>Back to Records</span>
        </Link>
      </div>

      {/* Header and Action Buttons matching Wireframe 5 */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '1rem',
      }}>
        <h1 style={{
          fontSize: '2.25rem',
          fontWeight: 800,
          color: '#2C1810',
          letterSpacing: '-0.03em',
        }}>
          Work Details
        </h1>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="btn-secondary"
            style={{
              padding: '0.55rem 1.25rem',
              fontSize: '0.85rem',
              borderRadius: '9999px',
            }}
          >
            <Edit3 size={15} color="#94A3B8" />
            <span>{isEditing ? 'Cancel' : 'Edit'}</span>
          </button>

          <button
            onClick={handleDelete}
            className="btn-secondary"
            style={{
              padding: '0.55rem 1.25rem',
              fontSize: '0.85rem',
              borderRadius: '9999px',
              color: '#F87171',
              borderColor: 'rgba(239, 68, 68, 0.25)',
            }}
          >
            <Trash2 size={15} color="#F87171" />
            <span>Delete</span>
          </button>
        </div>
      </div>

      {/* Main Content: 2-Column Split */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(0, 1.6fr) minmax(0, 1fr)',
        gap: '1.5rem',
        alignItems: 'start',
      }}>
        {/* Left Column: Main Record Details */}
        <div className="glass-panel" style={{ padding: '2rem 2.25rem', display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
          {isEditing ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: 700, color: '#7A6355' }}>TITLE</label>
              <input
                type="text"
                value={editedTitle}
                onChange={(e) => setEditedTitle(e.target.value)}
                className="input-capsule"
              />
              <label style={{ fontSize: '0.75rem', fontWeight: 700, color: '#7A6355' }}>DESCRIPTION</label>
              <textarea
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                rows={6}
                className="input-capsule"
                style={{ borderRadius: '16px', resize: 'vertical' }}
              />
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
                <button onClick={() => setIsEditing(false)} className="btn-secondary">Cancel</button>
                <button onClick={handleSaveEdit} className="btn-primary">Save Changes</button>
              </div>
            </div>
          ) : (
            <>
              {/* Title & Metadata Pills */}
              <div>
                <h2 style={{
                  fontSize: '1.65rem',
                  fontWeight: 700,
                  color: '#2C1810',
                  letterSpacing: '-0.02em',
                  marginBottom: '1rem',
                }}>
                  {activity.title}
                </h2>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
                  <div style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.4rem',
                    backgroundColor: 'rgba(139, 90, 43, 0.06)',
                    border: '1px solid rgba(139, 90, 43, 0.12)',
                    borderRadius: '9999px',
                    padding: '0.35rem 0.85rem',
                    fontSize: '0.8rem',
                    color: '#4A2E1A',
                  }}>
                    <Calendar size={14} color="#94A3B8" />
                    <span>{activity.displayDate || '18 Aug 2026'}</span>
                  </div>

                  <div style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.4rem',
                    backgroundColor: 'rgba(30, 58, 138, 0.25)',
                    border: '1px solid rgba(176, 120, 72, 0.25)',
                    borderRadius: '9999px',
                    padding: '0.35rem 0.85rem',
                    fontSize: '0.8rem',
                    color: '#B07848',
                  }}>
                    <Folder size={14} color="#B07848" />
                    <span>{activity.project}</span>
                  </div>
                </div>
              </div>

              {/* Description Section */}
              <div>
                <div style={{
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  letterSpacing: '0.08em',
                  color: '#A89080',
                  marginBottom: '0.75rem',
                }}>
                  DESCRIPTION
                </div>
                <p style={{
                  fontSize: '0.95rem',
                  lineHeight: '1.7',
                  color: '#4A2E1A',
                  margin: 0,
                }}>
                  {activity.text}
                </p>
              </div>

              {/* Artifacts Attached Container */}
              <div style={{
                border: '1px dashed rgba(139, 90, 43, 0.2)',
                borderRadius: '16px',
                padding: '1.75rem',
                textAlign: 'center',
                color: '#A89080',
                fontSize: '0.85rem',
                backgroundColor: 'rgba(255, 255, 255, 0.01)',
              }}>
                No related artifacts attached to this record.
              </div>
            </>
          )}
        </div>

        {/* Right Column: AI Classification & Record Attributes */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Card 1: AI CLASSIFICATION (Glowing Card matching Wireframe 5) */}
          <div className="ai-glow-card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', color: '#8B5A2B', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.06em' }}>
                <Sparkles size={14} color="#C8874A" />
                <span>AI CLASSIFICATION</span>
              </div>
              <span style={{
                fontSize: '0.7rem',
                color: '#4A2E1A',
                backgroundColor: 'rgba(139, 90, 43, 0.1)',
                border: '1px solid rgba(139, 90, 43, 0.18)',
                borderRadius: '9999px',
                padding: '0.2rem 0.6rem',
                fontWeight: 500,
              }}>
                Auto-Tagged
              </span>
            </div>

            <h3 style={{
              fontSize: '1.35rem',
              fontWeight: 700,
              color: '#2C1810',
              marginBottom: '0.6rem',
            }}>
              {activity.workType ? `${activity.workType} Work` : 'Technical Work'}
            </h3>

            <p style={{
              fontSize: '0.85rem',
              color: '#7A6355',
              lineHeight: '1.5',
              margin: 0,
            }}>
              {activity.aiClassificationSummary || 'High confidence classification based on keyword extraction (checkout, payment-state, race condition).'}
            </p>
          </div>

          {/* Card 2: RECORD ATTRIBUTES */}
          <div className="glass-panel" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            <div style={{ fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.08em', color: '#A89080' }}>
              RECORD ATTRIBUTES
            </div>

            {/* Category */}
            <div>
              <div style={{ fontSize: '0.8rem', color: '#7A6355', marginBottom: '0.5rem' }}>Category</div>
              <span className="tag-chip tag-chip-category" style={{ fontSize: '0.8rem', padding: '0.35rem 0.85rem' }}>
                {activity.category}
              </span>
            </div>

            {/* Skills Applied */}
            <div>
              <div style={{ fontSize: '0.8rem', color: '#7A6355', marginBottom: '0.5rem' }}>Skills Applied</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {activity.skills.map((skill) => (
                  <span key={skill} className="tag-chip" style={{ fontSize: '0.8rem', padding: '0.35rem 0.8rem' }}>
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Keywords */}
            {activity.keywords && activity.keywords.length > 0 && (
              <div>
                <div style={{ fontSize: '0.8rem', color: '#7A6355', marginBottom: '0.5rem' }}>Keywords</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                  {activity.keywords.map((kw) => (
                    <span key={kw} className="tag-chip" style={{ fontSize: '0.75rem', background: 'rgba(139, 90, 43, 0.06)', color: '#7A6355' }}>
                      #{kw}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
