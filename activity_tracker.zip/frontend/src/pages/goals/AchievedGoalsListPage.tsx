import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Target, Plus, Trophy, Award, Search, Filter, Sparkles } from 'lucide-react';
import { useGoalStore } from '../../store/goalStore';
import { GoalCard } from '../../components/goals/GoalCard';

export const AchievedGoalsListPage: React.FC = () => {
  const { goals } = useGoalStore();
  const navigate = useNavigate();
  const [selectedQuarter, setSelectedQuarter] = useState('all');

  const filteredGoals = selectedQuarter === 'all'
    ? goals
    : goals.filter((g) => g.quarter?.includes(selectedQuarter));

  const goalsWithImpact = goals.filter((g) => g.impactScore !== undefined);
  const avgImpact = goalsWithImpact.length > 0 
    ? Math.round(goalsWithImpact.reduce((sum, g) => sum + (g.impactScore || 0), 0) / goalsWithImpact.length)
    : null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        gap: '1rem',
      }}>
        <div>
          <h1 style={{
            fontSize: '2.25rem',
            fontWeight: 800,
            color: '#2C1810',
            letterSpacing: '-0.03em',
          }}>
            Achieved Goals
          </h1>
          <p style={{
            fontSize: '0.95rem',
            color: '#7A6355',
            marginTop: '0.35rem',
          }}>
            Strategic engineering milestones & quarterly goals achieved in 2026.
          </p>
        </div>

        <button
          onClick={() => navigate('/achieved-goals/new')}
          className="btn-primary"
          style={{
            padding: '0.65rem 1.35rem',
            fontSize: '0.9rem',
            fontWeight: 600,
          }}
        >
          <Plus size={18} strokeWidth={2.5} />
          <span>Add Achieved Goal</span>
        </button>
      </div>

      {/* Overview Stat Strip */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '1rem',
      }}>
        <div className="glass-panel" style={{ padding: '1.25rem 1.5rem' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#7A6355' }}>TOTAL MILESTONES</div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#2C1810', marginTop: '0.4rem' }}>{goals.length} Goals</div>
          <div style={{ fontSize: '0.75rem', color: '#5A8A5A', marginTop: '0.2rem' }}>100% on schedule</div>
        </div>

        <div className="glass-panel" style={{ padding: '1.25rem 1.5rem' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#7A6355' }}>AVG IMPACT SCORE</div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#C8874A', marginTop: '0.4rem' }}>
            {avgImpact !== null ? `${avgImpact}%` : 'N/A'}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#7A6355', marginTop: '0.2rem' }}>High organizational impact</div>
        </div>

        <div className="glass-panel" style={{ padding: '1.25rem 1.5rem' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#7A6355' }}>LINKED WORK LOGS</div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#B07848', marginTop: '0.4rem' }}>
            {goals.reduce((acc, g) => acc + g.relatedActivityIds.length, 0)} Logs
          </div>
          <div style={{ fontSize: '0.75rem', color: '#7A6355', marginTop: '0.2rem' }}>Evidence-backed milestones</div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div style={{ display: 'flex', gap: '0.75rem', borderBottom: '1px solid rgba(139, 90, 43, 0.1)', paddingBottom: '0.75rem' }}>
        {[
          { id: 'all', label: 'All Goals' },
          { id: 'Q3', label: 'Q3 2026' },
          { id: 'Q2', label: 'Q2 2026' },
          { id: 'Q1', label: 'Q1 2026' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedQuarter(tab.id)}
            className={selectedQuarter === tab.id ? 'btn-primary' : 'btn-ghost'}
            style={{
              padding: '0.45rem 1rem',
              fontSize: '0.825rem',
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Goals List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        {filteredGoals.map((goal) => (
          <GoalCard key={goal.id} goal={goal} />
        ))}
      </div>
    </div>
  );
};
