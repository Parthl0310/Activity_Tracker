import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  ChevronRight, 
  Calendar, 
  ChevronDown,
  Layers,
  Award,
  Edit2
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useActivityStore } from '../../store/activityStore';
import { apiClient } from '../../services/apiClient';

export const ReportsPage: React.FC = () => {
  const { user } = useAuthStore();
  const { activities } = useActivityStore();
  
  const [selectedPeriod, setSelectedPeriod] = useState<'yearly' | 'monthly' | 'weekly'>('yearly');
  const [selectedFormat, setSelectedFormat] = useState<'star' | 'narrative' | 'bullets'>('star');
  const [showPeriodDropdown, setShowPeriodDropdown] = useState(false);
  const [report, setReport] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const reviewYear = user?.reviewYear || new Date().getFullYear();

  React.useEffect(() => {
    if (selectedPeriod === 'yearly') {
      apiClient.reports.get(reviewYear).then(res => {
        if (res.data?.report) {
          setReport(res.data.report);
        }
      }).catch(console.error);
    } else {
      setReport(null);
    }
  }, [reviewYear, selectedPeriod]);

  const handleGenerateReport = async () => {
    setIsGenerating(true);
    try {
      const res = await apiClient.reports.generate(reviewYear);
      setReport(res.data?.report);
    } catch (e) {
      console.error(e);
      alert('Failed to generate report');
    } finally {
      setIsGenerating(false);
    }
  };

  // Filter activities based on selected period
  const filteredActivities = activities.filter((act) => {
    if (!act.workDate) return false;
    const date = new Date(act.workDate);
    if (selectedPeriod === 'yearly') return date.getFullYear() === reviewYear;
    if (selectedPeriod === 'monthly') return date.getFullYear() === reviewYear && date.getMonth() === new Date().getMonth();
    
    // Weekly (simple check for within last 7 days)
    if (selectedPeriod === 'weekly') {
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - date.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
      return diffDays <= 7;
    }
    return true;
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        gap: '1rem',
      }}>
        <div>
          <h1 style={{
            fontSize: '2.25rem',
            fontWeight: 800,
            color: '#2C1810',
            letterSpacing: '-0.03em',
          }}>
            Self-Evaluation Report
          </h1>
          <p style={{
            fontSize: '0.95rem',
            color: '#7A6355',
            marginTop: '0.35rem',
          }}>
            AI-synthesized performance evaluations formatted for annual review and promotion packets.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', position: 'relative' }}>
          {/* Period selector dropdown */}
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowPeriodDropdown(!showPeriodDropdown)}
              className="btn-secondary"
              style={{ padding: '0.65rem 1.15rem' }}
            >
              <Calendar size={15} color="#94A3B8" />
              <span>{selectedPeriod === 'yearly' ? '2026 Annual Cycle' : selectedPeriod === 'monthly' ? 'August 2026' : 'This Week'}</span>
              <ChevronDown size={14} color="#64748B" />
            </button>

            {showPeriodDropdown && (
              <div style={{
                position: 'absolute',
                top: 'calc(100% + 6px)',
                right: 0,
                width: '200px',
                backgroundColor: '#FEFCF8',
                border: '1px solid rgba(139, 90, 43, 0.15)',
                borderRadius: '12px',
                padding: '0.5rem',
                zIndex: 30,
                boxShadow: '0 10px 25px rgba(124, 77, 46, 0.12)',
              }}>
                <div
                  onClick={() => { setSelectedPeriod('yearly'); setShowPeriodDropdown(false); }}
                  style={{ padding: '0.5rem 0.75rem', fontSize: '0.85rem', color: selectedPeriod === 'yearly' ? '#C8874A' : '#7A6355', cursor: 'pointer', borderRadius: '6px' }}
                >
                  2026 Annual Cycle
                </div>
                <div
                  onClick={() => { setSelectedPeriod('monthly'); setShowPeriodDropdown(false); }}
                  style={{ padding: '0.5rem 0.75rem', fontSize: '0.85rem', color: selectedPeriod === 'monthly' ? '#C8874A' : '#7A6355', cursor: 'pointer', borderRadius: '6px' }}
                >
                  August 2026 Summary
                </div>
                <div
                  onClick={() => { setSelectedPeriod('weekly'); setShowPeriodDropdown(false); }}
                  style={{ padding: '0.5rem 0.75rem', fontSize: '0.85rem', color: selectedPeriod === 'weekly' ? '#C8874A' : '#7A6355', cursor: 'pointer', borderRadius: '6px' }}
                >
                  Weekly Snippet
                </div>
              </div>
            )}
          </div>

          <button className="btn-primary" style={{ padding: '0.65rem 1.35rem' }} onClick={handlePrint}>
            <Download size={15} />
            <span>Export PDF</span>
          </button>
        </div>
      </div>

      {/* Synthesis Format Switcher */}
      <div className="glass-panel" style={{ padding: '1rem 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <Sparkles size={16} color="#7C4D2E" />
          <span style={{ fontSize: '0.85rem', fontWeight: 600, color: '#4A2E1A' }}>AI Synthesis Framework:</span>
        </div>

        <div style={{ display: 'flex', gap: '0.5rem' }}>
          {[
            { id: 'star', label: 'STAR Format (Situation-Task-Action-Result)' },
            { id: 'narrative', label: 'Executive Paragraph' },
            { id: 'bullets', label: 'Bulleted Highlights' },
          ].map((fmt) => (
            <button
              key={fmt.id}
              onClick={() => setSelectedFormat(fmt.id as any)}
              className={selectedFormat === fmt.id ? 'btn-primary' : 'btn-secondary'}
              style={{ fontSize: '0.75rem', padding: '0.35rem 0.85rem' }}
            >
              {fmt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Report Preview Card */}
      <div className="glass-panel" style={{ padding: '2.25rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.75rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.4rem' }}>
              <span className="tag-chip tag-chip-category" style={{ fontSize: '0.75rem' }}>2026 Annual Evaluation</span>
              <span style={{ fontSize: '0.75rem', color: '#5A8A5A', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                <CheckCircle2 size={13} /> 8 of 8 Sections Complete
              </span>
            </div>
            <h2 style={{ fontSize: '1.35rem', fontWeight: 700, color: '#2C1810' }}>
              {user?.name || 'Kavya Deshmukh'} — Senior Backend Engineer Review Packet
            </h2>
          </div>

          <div style={{
            backgroundColor: 'rgba(124, 77, 46, 0.1)',
            border: '1px solid rgba(124, 77, 46, 0.25)',
            borderRadius: '9999px',
            padding: '0.35rem 0.85rem',
            fontSize: '0.8rem',
            color: '#8B5A2B',
            display: 'flex',
            alignItems: 'center',
            gap: '0.35rem',
          }}>
            <Sparkles size={14} color="#C8874A" />
            <span>AI Verified</span>
          </div>
        </div>

        {/* Generated Report Content */}
        {report && (
          <div className="print-container" style={{ marginBottom: '2rem', padding: '1.5rem', backgroundColor: 'white', borderRadius: '12px', border: '1px solid #eee' }}>
            <h3 style={{ fontSize: '1.2rem', color: '#2C1810', marginBottom: '1rem', borderBottom: '2px solid #7C4D2E', paddingBottom: '0.5rem' }}>Executive Summary</h3>
            <p style={{ whiteSpace: 'pre-wrap', fontSize: '0.9rem', color: '#4A2E1A', marginBottom: '1.5rem', lineHeight: '1.6' }}>{report.report.executiveSummary}</p>
            
            <h3 style={{ fontSize: '1.1rem', color: '#2C1810', marginBottom: '0.75rem', borderBottom: '1px solid #ddd', paddingBottom: '0.25rem' }}>Major Contributions</h3>
            <p style={{ whiteSpace: 'pre-wrap', fontSize: '0.9rem', color: '#4A2E1A', marginBottom: '1.5rem', lineHeight: '1.6' }}>{report.report.majorContributions}</p>
            
            <h3 style={{ fontSize: '1.1rem', color: '#2C1810', marginBottom: '0.75rem', borderBottom: '1px solid #ddd', paddingBottom: '0.25rem' }}>Technical Work</h3>
            <p style={{ whiteSpace: 'pre-wrap', fontSize: '0.9rem', color: '#4A2E1A', marginBottom: '1.5rem', lineHeight: '1.6' }}>{report.report.technicalWork}</p>

            <h3 style={{ fontSize: '1.1rem', color: '#2C1810', marginBottom: '0.75rem', borderBottom: '1px solid #ddd', paddingBottom: '0.25rem' }}>Skills Demonstrated</h3>
            <p style={{ whiteSpace: 'pre-wrap', fontSize: '0.9rem', color: '#4A2E1A', marginBottom: '1.5rem', lineHeight: '1.6' }}>{report.report.skillsDemonstrated}</p>
          </div>
        )}

        {!report && selectedPeriod === 'yearly' && (
          <div style={{ textAlign: 'center', padding: '2rem', marginBottom: '2rem', backgroundColor: 'rgba(124, 77, 46, 0.05)', borderRadius: '12px' }}>
            <p style={{ color: '#7A6355', marginBottom: '1rem' }}>No AI-generated report available for this period.</p>
            <button onClick={handleGenerateReport} disabled={isGenerating} className="btn-primary">
              <Sparkles size={16} />
              <span>{isGenerating ? 'Generating...' : 'Generate AI Report'}</span>
            </button>
          </div>
        )}

        <h3 style={{ fontSize: '1.2rem', fontWeight: 700, color: '#2C1810', marginBottom: '1rem', marginTop: '2rem' }}>Detailed Activity Log</h3>

        {/* Filtered Records Rendered */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }} className="print-container">
          {filteredActivities.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '3rem 1rem', color: '#A89080' }}>
              <p>No work records found for this period.</p>
            </div>
          ) : (
            filteredActivities.map((act) => (
              <div
                key={act.id}
                className="glass-card-interactive"
                style={{
                  padding: '1.25rem 1.5rem',
                  borderRadius: '16px',
                  pageBreakInside: 'avoid',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', marginBottom: '1rem' }}>
                  <FileText size={16} color="#7C4D2E" />
                  <span style={{ fontSize: '0.95rem', fontWeight: 600, color: '#4A2E1A' }}>
                    {act.title || act.project || 'Work Entry'} — {act.displayDate}
                  </span>
                </div>

                {/* Section Content Preview */}
                <div>
                  {selectedFormat === 'star' ? (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem' }}>
                      <div style={{ backgroundColor: 'rgba(139, 90, 43, 0.05)', padding: '0.75rem', borderRadius: '8px' }}>
                        <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#7C4D2E' }}>SITUATION</div>
                        <div style={{ fontSize: '0.8rem', color: '#4A2E1A', marginTop: '0.2rem' }}>
                          Context: {act.project ? `${act.project} project` : 'General workspace'} under the {act.category || 'general'} category.
                        </div>
                      </div>
                      <div style={{ backgroundColor: 'rgba(139, 90, 43, 0.05)', padding: '0.75rem', borderRadius: '8px' }}>
                        <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#7C4D2E' }}>TASK</div>
                        <div style={{ fontSize: '0.8rem', color: '#4A2E1A', marginTop: '0.2rem' }}>
                          {act.title ? act.title : (act.workType ? `Complete ${act.workType} task` : 'Execute assigned work')}.
                        </div>
                      </div>
                      <div style={{ backgroundColor: 'rgba(139, 90, 43, 0.05)', padding: '0.75rem', borderRadius: '8px' }}>
                        <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#5A8A5A' }}>ACTION</div>
                        <div style={{ fontSize: '0.8rem', color: '#4A2E1A', marginTop: '0.2rem' }}>
                          {act.aiRefinedText || act.text}
                        </div>
                      </div>
                      <div style={{ backgroundColor: 'rgba(139, 90, 43, 0.05)', padding: '0.75rem', borderRadius: '8px' }}>
                        <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#8B5A1A' }}>RESULT</div>
                        <div style={{ fontSize: '0.8rem', color: '#4A2E1A', marginTop: '0.2rem' }}>
                          {(() => {
                            const t = (act.text || '').toLowerCase();
                            if (t.includes('result:')) return act.text.split(/result:/i)[1].trim();
                            if (t.includes('outcome:')) return act.text.split(/outcome:/i)[1].trim();
                            if (act.isAchievement) return 'Work was marked as a notable achievement.';
                            return 'Result not specified in the original entry.';
                          })()}
                        </div>
                      </div>
                    </div>
                  ) : selectedFormat === 'bullets' ? (
                    <ul style={{ fontSize: '0.9rem', lineHeight: '1.6', color: '#4A2E1A', margin: 0, paddingLeft: '1.25rem' }}>
                      <li><strong>Project:</strong> {act.project}</li>
                      <li><strong>Category:</strong> {act.category}</li>
                      <li><strong>Details:</strong> {act.text}</li>
                      {act.skills && act.skills.length > 0 && <li><strong>Skills:</strong> {act.skills.join(', ')}</li>}
                    </ul>
                  ) : (
                    <p style={{ fontSize: '0.9rem', lineHeight: '1.6', color: '#4A2E1A', margin: 0 }}>
                      On {act.displayDate}, I worked on the <strong>{act.project}</strong> project under the category of <em>{act.category}</em>. Specifically, {act.text}
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
