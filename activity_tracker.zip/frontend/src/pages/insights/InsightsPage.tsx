import React from 'react';
import { useActivityStore } from '../../store/activityStore';
import { useAuthStore } from '../../store/authStore';

export const InsightsPage: React.FC = () => {
  const { user } = useAuthStore();
  const { activities } = useActivityStore();

  const colors = ['#7C4D2E', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6'];

  // Calculate real skill distribution
  const allSkills = activities.flatMap(a => a.skills || []);
  const totalSkills = allSkills.length || 1; // avoid division by zero
  const skillCounts = allSkills.reduce((acc, skill) => {
    acc[skill] = (acc[skill] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sortedSkills = Object.entries(skillCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([skill, count], i) => ({
      skill,
      percentage: Math.round((count / totalSkills) * 100),
      color: colors[i % colors.length],
    }));

  // Calculate work type breakdown
  const totalActivities = activities.length || 1;
  const workTypeCounts = activities.reduce((acc, a) => {
    const type = a.workType || 'Uncategorized';
    acc[type] = (acc[type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sortedWorkTypes = Object.entries(workTypeCounts)
    .sort((a, b) => b[1] - a[1])
    .map(([type, count]) => ({
      label: type,
      val: `${Math.round((count / totalActivities) * 100)}%`,
      desc: `${count} entries logged`,
    }));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      {/* Header */}
      <div>
        <h1 style={{
          fontSize: '2.25rem',
          fontWeight: 800,
          color: '#2C1810',
          letterSpacing: '-0.03em',
        }}>
          AI Engineering Insights
        </h1>
        <p style={{
          fontSize: '0.95rem',
          color: '#7A6355',
          marginTop: '0.35rem',
        }}>
          Aggregated productivity patterns, skill vectors, and AI career recommendations.
        </p>
      </div>

      {/* Grid: Skill Distribution & Weekly Work Breakdown */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
        {/* Skills Distribution */}
        <div className="glass-panel" style={{ padding: '1.75rem' }}>
          <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#2C1810', marginBottom: '1.25rem' }}>
            Skill Distribution ({user?.reviewYear || new Date().getFullYear()})
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {sortedSkills.length === 0 && <div style={{ fontSize: '0.85rem', color: '#7A6355' }}>No skills logged yet.</div>}
            {sortedSkills.map((item) => (
              <div key={item.skill}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.35rem' }}>
                  <span style={{ color: '#4A2E1A' }}>{item.skill}</span>
                  <span style={{ color: '#7A6355', fontWeight: 600 }}>{item.percentage}%</span>
                </div>
                <div style={{ height: '8px', backgroundColor: 'rgba(139, 90, 43, 0.07)', borderRadius: '9999px', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${item.percentage}%`, backgroundColor: item.color, borderRadius: '9999px' }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Work Breakdown By Type */}
        <div className="glass-panel" style={{ padding: '1.75rem' }}>
          <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#2C1810', marginBottom: '1.25rem' }}>
            Work Type Breakdown
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {sortedWorkTypes.length === 0 && <div style={{ fontSize: '0.85rem', color: '#7A6355' }}>No entries logged yet.</div>}
            {sortedWorkTypes.map((w) => (
              <div key={w.label} className="glass-card-interactive" style={{ padding: '0.85rem 1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.875rem', fontWeight: 600, color: '#2C1810' }}>{w.label}</span>
                  <span style={{ fontSize: '0.9rem', fontWeight: 800, color: '#7C4D2E' }}>{w.val}</span>
                </div>
                <div style={{ fontSize: '0.75rem', color: '#A89080', marginTop: '0.2rem' }}>{w.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
