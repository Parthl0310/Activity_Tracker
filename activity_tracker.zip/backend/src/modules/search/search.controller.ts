import { Request, Response, NextFunction } from 'express';
import { SearchService } from './search.service.js';

export class SearchController {
  private searchService: SearchService;

  constructor() {
    this.searchService = new SearchService();
  }

  public queryAssistant = async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      const userId = req.user!.userId;
      const { query } = req.body;

      if (!query || typeof query !== 'string') {
        res.status(400).json({ status: 'error', message: 'Query is required and must be a string' });
        return;
      }

      const result = await this.searchService.queryAssistant(userId, query);

      res.status(200).json({
        status: 'success',
        data: result,
      });
    } catch (error) {
      next(error);
    }
  };
}
