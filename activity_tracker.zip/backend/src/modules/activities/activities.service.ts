import mongoose from 'mongoose';
import { Activity, IActivity } from '../../models/Activity.js';
import { AppError } from '../../middleware/error.middleware.js';
import {
  CreateActivityInput,
  UpdateActivityInput,
  ListActivitiesQuery,
} from './activities.dto.js';
import { addEnrichmentJob } from '../../jobs/queue.js';
import { detectVagueEntry } from '@activity-tracker/ai';

export interface PaginatedActivities {
  activities: IActivity[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

export class ActivitiesService {
  public async createActivity(
    userId: string,
    input: CreateActivityInput
  ): Promise<IActivity> {
    const activity = await Activity.create({
      userId: new mongoose.Types.ObjectId(userId),
      text: input.text,
      workDate: input.workDate,
      project: input.project || '',
      category: input.category,
      skills: input.skills || [],
      keywords: input.keywords || [],
      workType: input.workType,
      vectorIndexed: false,
      enrichmentStatus: 'pending',
    });

    // Trigger background AI enrichment
    await addEnrichmentJob({ activityId: activity._id.toString(), userId });

    return activity;
  }

  public async listActivities(
    userId: string,
    query: ListActivitiesQuery
  ): Promise<PaginatedActivities> {
    const filter: Record<string, any> = {
      userId: new mongoose.Types.ObjectId(userId),
    };

    if (query.from || query.to) {
      filter.workDate = {};
      if (query.from) {
        filter.workDate.$gte = new Date(query.from);
      }
      if (query.to) {
        filter.workDate.$lte = new Date(query.to);
      }
    }

    if (query.project) {
      filter.project = { $regex: query.project, $options: 'i' };
    }

    if (query.category) {
      filter.category = query.category;
    }

    if (query.q) {
      const words = query.q.trim().split(/\s+/).filter(Boolean);
      if (words.length > 0) {
        filter.$and = words.map((word) => ({
          $or: [
            { text: { $regex: word, $options: 'i' } },
            { aiRefinedText: { $regex: word, $options: 'i' } },
            { project: { $regex: word, $options: 'i' } },
            { category: { $regex: word, $options: 'i' } },
            { workType: { $regex: word, $options: 'i' } },
            { skills: { $in: [new RegExp(word, 'i')] } },
            { keywords: { $in: [new RegExp(word, 'i')] } },
          ]
        }));
      }
    }

    const page = query.page || 1;
    const limit = query.limit || 20;
    const skip = (page - 1) * limit;

    const [activities, total] = await Promise.all([
      Activity.find(filter)
        .sort({ workDate: -1, createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Activity.countDocuments(filter),
    ]);

    return {
      activities,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  }

  public async getActivityById(
    userId: string,
    activityId: string
  ): Promise<IActivity> {
    const activity = await Activity.findOne({
      _id: activityId,
      userId: new mongoose.Types.ObjectId(userId),
    });

    if (!activity) {
      throw new AppError('Activity not found', 404);
    }

    return activity;
  }

  public async updateActivity(
    userId: string,
    activityId: string,
    input: UpdateActivityInput
  ): Promise<IActivity> {
    const activity = await Activity.findOne({
      _id: activityId,
      userId: new mongoose.Types.ObjectId(userId),
    });

    if (!activity) {
      throw new AppError('Activity not found', 404);
    }

    const textChanged = input.text !== undefined && input.text !== activity.text;

    if (input.text !== undefined) activity.text = input.text;
    if (input.workDate !== undefined) activity.workDate = input.workDate;
    if (input.project !== undefined) activity.project = input.project;
    if (input.category !== undefined) activity.category = input.category;
    if (input.skills !== undefined) activity.skills = input.skills;
    if (input.keywords !== undefined) activity.keywords = input.keywords;
    if (input.workType !== undefined) activity.workType = input.workType;

    if (textChanged) {
      activity.enrichmentStatus = 'pending';
      activity.vectorIndexed = false;
      await addEnrichmentJob({ activityId: activity._id.toString(), userId });
    }

    await activity.save();
    return activity;
  }

  public async deleteActivity(
    userId: string,
    activityId: string
  ): Promise<void> {
    const result = await Activity.findOneAndDelete({
      _id: activityId,
      userId: new mongoose.Types.ObjectId(userId),
    });

    if (!result) {
      throw new AppError('Activity not found', 404);
    }
  }

  public async improveEntry(
    userId: string,
    activityId: string
  ): Promise<{ originalText: string; suggestion: string }> {
    const activity = await this.getActivityById(userId, activityId);

    const result = await detectVagueEntry(activity.text);

    return {
      originalText: activity.text,
      suggestion: (result.isVague ? result.suggestion : activity.text) || activity.text,
    };
  }
}

export const activitiesService = new ActivitiesService();
