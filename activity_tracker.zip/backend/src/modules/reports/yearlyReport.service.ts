import mongoose from 'mongoose';
import {
  YearlyReport,
  IYearlyReport,
  IYearlyReportContent,
  ReportSectionName,
} from '../../models/YearlyReport.js';
import { MonthlySummary } from '../../models/MonthlySummary.js';
import { Activity } from '../../models/Activity.js';
import { AchievedGoal } from '../../models/AchievedGoal.js';
import { AppError } from '../../middleware/error.middleware.js';
import { generateYearlyReport as aiGenerateYearlyReport } from '@activity-tracker/ai';

export interface ReportAvailability {
  year: number;
  hasEnoughData: boolean;
  activityCount: number;
  monthlySummaryCount: number;
  achievedGoalCount: number;
  canGenerate: boolean;
}

export class YearlyReportService {
  public async checkAvailability(
    userId: string,
    year: number
  ): Promise<ReportAvailability> {
    const userObjectId = new mongoose.Types.ObjectId(userId);
    const yearStart = new Date(year, 0, 1, 0, 0, 0, 0);
    const yearEnd = new Date(year, 11, 31, 23, 59, 59, 999);

    const [activityCount, monthlySummaryCount, achievedGoalCount] =
      await Promise.all([
        Activity.countDocuments({
          userId: userObjectId,
          workDate: { $gte: yearStart, $lte: yearEnd },
        }),
        MonthlySummary.countDocuments({
          userId: userObjectId,
          year,
        }),
        AchievedGoal.countDocuments({
          userId: userObjectId,
          completedAt: { $gte: yearStart, $lte: yearEnd },
        }),
      ]);

    const canGenerate = activityCount > 0 || monthlySummaryCount > 0;

    return {
      year,
      hasEnoughData: activityCount >= 10 || monthlySummaryCount >= 2,
      activityCount,
      monthlySummaryCount,
      achievedGoalCount,
      canGenerate,
    };
  }

  public async generateReport(
    userId: string,
    year: number
  ): Promise<IYearlyReport> {
    const userObjectId = new mongoose.Types.ObjectId(userId);
    const yearStart = new Date(year, 0, 1, 0, 0, 0, 0);
    const yearEnd = new Date(year, 11, 31, 23, 59, 59, 999);

    // Fetch data sources
    const [monthlySummaries, activities, goals] = await Promise.all([
      MonthlySummary.find({ userId: userObjectId, year }).sort({ month: 1 }),
      Activity.find({
        userId: userObjectId,
        workDate: { $gte: yearStart, $lte: yearEnd },
      }),
      AchievedGoal.find({
        userId: userObjectId,
        completedAt: { $gte: yearStart, $lte: yearEnd },
      }),
    ]);

    const cleanActivities = activities.map(a => ({
      date: a.workDate,
      project: a.project,
      category: a.category,
      workType: a.workType,
      text: a.text,
      aiRefinedText: a.aiRefinedText,
      skills: a.skills,
      keywords: a.keywords
    }));

    const cleanSummaries = monthlySummaries.map(m => ({
      month: m.month,
      summary: m.summary?.aiSummary || '',
      projects: m.summary?.majorWorkAreas || [],
      skills: m.summary?.skillsDemonstrated || []
    }));

    const cleanGoals = goals.map(g => ({ 
      title: g.title, 
      description: g.description, 
      date: g.completedAt 
    }));

    const generatedSections = await aiGenerateYearlyReport(userId, year, cleanActivities, cleanSummaries, cleanGoals);

    const reportContent: IYearlyReportContent = {
      executiveSummary: generatedSections['Executive Summary'].sectionText,
      majorContributions: generatedSections['Major Contributions'].sectionText,
      technicalWork: generatedSections['Technical Work'].sectionText,
      skillsDemonstrated: generatedSections['Skills Demonstrated'].sectionText,
      projects: generatedSections['Projects'].sectionText,
      learningAndDevelopment: generatedSections['Learning and Development'].sectionText,
      achievedGoals: goals.length > 0
        ? goals.map((g, idx) => `${idx + 1}. ${g.title}: ${g.description}`).join('\n')
        : 'Completed planned engineering cycle tasks.',
      overallYearSummary: `Overall, ${year} was characterized by consistent output, solid technical execution, and measurable contributions across all key milestones.`,
    };

    // Find if draft exists or create new version
    const latestVersionDoc = await YearlyReport.findOne({
      userId: userObjectId,
      year,
    }).sort({ version: -1 });

    if (latestVersionDoc && latestVersionDoc.status === 'draft') {
      latestVersionDoc.report = reportContent;
      await latestVersionDoc.save();
      return latestVersionDoc;
    }

    const nextVersion = latestVersionDoc ? latestVersionDoc.version + 1 : 1;

    const newReport = await YearlyReport.create({
      userId: userObjectId,
      year,
      report: reportContent,
      version: nextVersion,
      status: 'draft',
    });

    return newReport;
  }

  public async getReport(
    userId: string,
    year: number
  ): Promise<IYearlyReport> {
    const report = await YearlyReport.findOne({
      userId: new mongoose.Types.ObjectId(userId),
      year,
    }).sort({ version: -1 });

    if (!report) {
      throw new AppError(`No yearly report found for year ${year}`, 404);
    }

    return report;
  }

  public async editSection(
    userId: string,
    year: number,
    sectionName: ReportSectionName,
    content: string
  ): Promise<IYearlyReport> {
    const report = await this.getReport(userId, year);

    if (report.status === 'final') {
      throw new AppError('Cannot edit a finalized report. Please generate a new draft revision.', 400);
    }

    report.report[sectionName] = content;
    await report.save();
    return report;
  }

  public async regenerateSection(
    userId: string,
    year: number,
    sectionName: ReportSectionName
  ): Promise<IYearlyReport> {
    const report = await this.getReport(userId, year);

    if (report.status === 'final') {
      throw new AppError('Cannot regenerate section on a finalized report.', 400);
    }

    // Refresh data and regenerate that section
    const freshDraft = await this.generateReport(userId, year);
    report.report[sectionName] = freshDraft.report[sectionName];
    await report.save();
    return report;
  }

  public async finalizeReport(
    userId: string,
    year: number
  ): Promise<IYearlyReport> {
    const report = await this.getReport(userId, year);

    if (report.status === 'final') {
      return report;
    }

    report.status = 'final';
    await report.save();
    return report;
  }

  public async listReportVersions(
    userId: string,
    year: number
  ): Promise<IYearlyReport[]> {
    const versions = await YearlyReport.find({
      userId: new mongoose.Types.ObjectId(userId),
      year,
    }).sort({ version: -1 });

    return versions;
  }
}

export const yearlyReportService = new YearlyReportService();
