import { Activity } from '../models/Activity.js';
import { enrichActivity, embed, upsertVector } from '@activity-tracker/ai';

export async function enrichmentProcessor(data: { activityId: string; userId: string }) {
  const { activityId, userId } = data;

  const activity = await Activity.findOne({ _id: activityId, userId });
  if (!activity) {
    throw new Error(`Activity ${activityId} not found`);
  }

  // 1. Enrich with Gemini AI
  try {
    const enriched = await enrichActivity(
      userId.toString(),
      activityId.toString(),
      activity.text
    );

    if (!activity.project) activity.project = enriched.project || undefined;
    if (!activity.category) activity.category = enriched.category;
    activity.skills = enriched.skills;
    activity.keywords = enriched.keywords;
    if (!activity.workType) activity.workType = enriched.workType;
    activity.aiRefinedText = enriched.aiRefinedText;
    activity.enrichmentStatus = 'done';

    await activity.save();
    console.log(`[AI] Activity ${activityId} enriched ✅`);
  } catch (e: any) {
    activity.enrichmentStatus = 'failed';
    await activity.save();
    console.error(`[AI] Enrichment failed for ${activityId}:`, e.message);
    throw e;
  }

  // 2. Embed & Index in Pinecone
  const embedText = `Project: ${activity.project || 'None'}\nCategory: ${activity.category || 'None'}\nText: ${activity.aiRefinedText || activity.text}\nSkills: ${(activity.skills || []).join(', ')}`;

  try {
    const vector = await embed(embedText);
    await upsertVector('activities', activity._id.toString(), vector, {
      userId: userId.toString(),
      workDate: activity.workDate.toISOString(),
    });
    activity.vectorIndexed = true;
    await activity.save();
    console.log(`[AI] Activity ${activityId} indexed in Pinecone ✅`);
  } catch (e: any) {
    console.warn(`[AI] Pinecone indexing failed for ${activityId}:`, e.message);
    // Don't rethrow — MongoDB save already succeeded
  }
}
