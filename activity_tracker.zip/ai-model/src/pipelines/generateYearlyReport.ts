import { completeJSON } from "../llm/geminiClient";
import { retrieveContext } from "./ragQuery";
import {
  YEARLY_REPORT_SYSTEM_PROMPT_TEMPLATE,
  buildYearlyReportUserPrompt,
} from "../prompts/yearlyReport.prompt";
import {
  yearlyReportSectionSchema,
  type YearlyReportSectionResponse,
} from "../schemas/yearlyReportSection.schema";

export const REPORT_SECTIONS = [
  "Executive Summary",
  "Major Contributions",
  "Technical Work",
  "Skills Demonstrated",
  "Projects",
  "Learning and Development",
] as const;

export type ReportSectionName = (typeof REPORT_SECTIONS)[number];

// A mapping of section names to specific RAG queries
const SECTION_QUERIES: Record<ReportSectionName, string> = {
  "Executive Summary": "high level overview, major milestones, key achievements",
  "Major Contributions": "major contributions, impact, delivered features, significant work",
  "Technical Work": "technical contributions and implementations, architecture, code, systems",
  "Skills Demonstrated": "skills, technologies, tools, languages used or demonstrated",
  "Projects": "projects worked on, epics, initiatives",
  "Learning and Development": "learning, training, research, new skills acquired, discussions",
};

export async function generateYearlyReport(
  userId: string,
  year: number,
  activities: unknown[],
  monthlySummaries: unknown[],
  achievedGoals: unknown[]
): Promise<Record<ReportSectionName, YearlyReportSectionResponse>> {
  // Use a partial record while building up the response
  const result: Partial<Record<ReportSectionName, YearlyReportSectionResponse>> = {};

  for (const section of REPORT_SECTIONS) {
    const queryFocus = SECTION_QUERIES[section];
    const systemPrompt = YEARLY_REPORT_SYSTEM_PROMPT_TEMPLATE(section, year);
    const userPrompt = buildYearlyReportUserPrompt(activities, monthlySummaries, achievedGoals, queryFocus);

    // Call the LLM
    const sectionResponse = await completeJSON<YearlyReportSectionResponse>(
      systemPrompt,
      userPrompt,
      yearlyReportSectionSchema
    );

    // We no longer retrieve chunks via RAG since we pass raw data directly,
    // so we provide a mock source chunk to bypass hallucination validation failure
    // while the schema still expects sourceChunkIds.
    sectionResponse.sourceChunkIds = ["Direct yearly data extraction"];

    result[section] = sectionResponse;
  }

  // Cast to the full record now that all sections are populated
  return result as Record<ReportSectionName, YearlyReportSectionResponse>;
}
