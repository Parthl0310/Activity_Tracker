import { completeJSON } from "../llm/geminiClient";
import { ENRICHMENT_SYSTEM_PROMPT, buildEnrichmentUserPrompt } from "../prompts/enrichment.prompt";
import { activityEnrichmentSchema, type ActivityEnrichmentResponse } from "../schemas/activityEnrichment.schema";

export async function enrichActivity(
  _userId: string,
  _activityId: string,
  text: string
): Promise<ActivityEnrichmentResponse> {
  const userPrompt = buildEnrichmentUserPrompt(text);
  
  return completeJSON<ActivityEnrichmentResponse>(
    ENRICHMENT_SYSTEM_PROMPT,
    userPrompt,
    activityEnrichmentSchema
  );
}
