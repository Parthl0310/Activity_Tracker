import { completeJSON } from "../llm/geminiClient";
import { VAGUE_ENTRY_SYSTEM_PROMPT, buildVagueEntryUserPrompt } from "../prompts/vagueEntry.prompt";
import { vagueEntrySchema, type VagueEntryResponse } from "../schemas/vagueEntry.schema";

export async function detectVagueEntry(text: string): Promise<VagueEntryResponse> {
  const userPrompt = buildVagueEntryUserPrompt(text);
  
  return completeJSON<VagueEntryResponse>(
    VAGUE_ENTRY_SYSTEM_PROMPT,
    userPrompt,
    vagueEntrySchema
  );
}
