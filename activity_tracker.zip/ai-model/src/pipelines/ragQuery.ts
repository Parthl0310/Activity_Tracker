import { queryVectors } from "../vectorstore/pineconeClient";
import { embed } from "../embeddings/localModel";

type Namespace = "activities" | "monthly-summary-chunks";

export type RetrievedContext = {
  score?: number;
  [key: string]: unknown;
};

export async function retrieveContext(
  userId: string,
  query: string,
  namespace: Namespace,
  k = 8
): Promise<RetrievedContext[]> {
  const queryVector = await embed(query);
  const matches = await queryVectors(namespace, userId, queryVector, k);
  
  return matches.map(m => ({ score: m.score, ...m.metadata }));
}
