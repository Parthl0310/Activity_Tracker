import { GoogleGenerativeAI, ResponseSchema } from "@google/generative-ai";
import { withBackoff } from "../utils/retry";

// Initialize genAI with the API key from environment variables.
// The exclamation mark tells TypeScript we're sure this will be defined at runtime.
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function complete(systemPrompt: string, userPrompt: string): Promise<string> {
  return withBackoff(async () => {
    const model = genAI.getGenerativeModel({
      model: process.env.GEMINI_MODEL ?? "gemini-2.0-flash",
      systemInstruction: systemPrompt,
    });
    const result = await model.generateContent(userPrompt);
    return result.response.text();
  });
}

export async function completeJSON<T>(
  systemPrompt: string,
  userPrompt: string,
  responseSchema: ResponseSchema | object
): Promise<T> {
  return withBackoff(async () => {
    const model = genAI.getGenerativeModel({
      model: process.env.GEMINI_MODEL ?? "gemini-2.0-flash",
      systemInstruction: systemPrompt,
      generationConfig: {
        responseMimeType: "application/json",
        // Cast is used here in case the passed object is loosely typed 
        // but conforms to the expected structure.
        responseSchema: responseSchema as ResponseSchema,
        temperature: 0.2,
      },
    });
    
    const result = await model.generateContent(userPrompt);
    return JSON.parse(result.response.text()) as T;
  });
}
