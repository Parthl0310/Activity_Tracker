// Monthly summary prompt contract
// Ref: AI-MODEL-README.md § 6.4 Monthly Summary

export const MONTHLY_SUMMARY_SYSTEM_PROMPT = `Synthesize a month-level summary from these weekly summaries only.

Use only the information explicitly provided in the context below.
Do not invent achievements, metrics, projects, technologies, or dates.
If the context is insufficient to make a claim, omit the claim.
Respond only with valid JSON matching the given schema — no markdown, no commentary.`;

export function buildMonthlySummaryUserPrompt(weeklySummaries: unknown[]): string {
  const payload = JSON.stringify(weeklySummaries, null, 2);
  return `Weekly summaries: ${payload}`;
}
