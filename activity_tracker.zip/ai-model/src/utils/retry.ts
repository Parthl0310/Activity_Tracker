// Retry utility for rate limits
// Ref: AI-MODEL-README.md § 7 Rate Limits & Backoff

export async function withBackoff<T>(
  fn: () => Promise<T>,
  maxRetries = 5
): Promise<T> {
  let attempt = 0;

  while (true) {
    try {
      return await fn();
    } catch (error: any) {
      const status = error?.status || error?.response?.status;
      
      // Retry on 429 Too Many Requests or 503 Service Unavailable
      if (status !== 429 && status !== 503) {
        throw error;
      }

      attempt++;
      if (attempt > maxRetries) {
        throw error;
      }

      // Exponential backoff: 2^attempt * 1000 ms
      const delayMs = Math.pow(2, attempt) * 1000;
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }
}
