import { Pinecone, RecordMetadata } from "@pinecone-database/pinecone";

// Initialize the Pinecone client.
// The exclamation marks tell TypeScript these env vars will be provided at runtime.
const pc = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
const index = pc.index(process.env.PINECONE_INDEX!);

type Namespace = "activities" | "monthly-summary-chunks";

export async function upsertVector(
  namespace: Namespace,
  id: string,
  vector: number[],
  metadata: RecordMetadata // MUST include userId
): Promise<void> {
  await index.namespace(namespace).upsert([
    {
      id,
      values: vector,
      metadata,
    },
  ]);
}

export async function queryVectors(
  namespace: Namespace,
  userId: string,
  vector: number[],
  topK = 8
) {
  const result = await index.namespace(namespace).query({
    vector,
    topK,
    filter: { userId: { $eq: userId } },
    includeMetadata: true,
  });
  
  return result.matches ?? [];
}

export async function deleteVector(namespace: Namespace, id: string): Promise<void> {
  await index.namespace(namespace).deleteOne(id);
}
